package com.example.sampleconstraintlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Deklarasi variabel untuk button
    Button btnLogin;

    //Deklarasi variabel untuk EditText
    EditText edemail, edpassword;

    //Deklarasi variabel untuk menyimpan email dan password
    String nama, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //menghubungkan variabel btnLogin dengan komponen button pada layout
        btnLogin=findViewById(R.id.btSignin);

        //menghubungkan variabel edmail dengan komponen button pada layout
        edemail=findViewById(R.id.edMail);

        //menghubungkan variabel edpassword dengan komponen button pada layout
        edpassword=findViewById(R.id.edPassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //menyimpan input user di editText email kedalam variabel nama
                nama = edemail.getText().toString();

                //menyimpan input user di edittext password kedalam variabel password
                password = edpassword.getText().toString();

                //membuat variabel toast dan membuat toast dengan menambahkan variabel nama dan password
                Toast t = Toast.makeText(getApplicationContext(),
                        "Login Sukses",Toast.LENGTH_LONG);
                Toast u = Toast.makeText(getApplicationContext(),
                        "Password Salah",Toast.LENGTH_LONG);
                Toast v = Toast.makeText(getApplicationContext(),
                        "Email Salah",Toast.LENGTH_LONG);
                Toast w = Toast.makeText(getApplicationContext(),
                        "Email dan Password salah",Toast.LENGTH_LONG);

                t.show();
                u.show();
                v.show();
                w.show();
            }
        });
    }
}